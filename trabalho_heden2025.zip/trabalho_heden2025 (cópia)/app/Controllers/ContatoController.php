<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class ContatoController extends Controller
{
    public function index()
    {
        return view('contato');
    }

    public function enviar()
    {
        helper(['form']);

        $rules = [
            'nome'     => 'required',
            'email'    => 'required|valid_email',
            'assunto'  => 'required',
            'mensagem' => 'required'
        ];

        if (!$this->validate($rules)) {
            return view('contato', [
                'validation' => $this->validator
            ]);
        }

        // Aqui você pode processar os dados (salvar no banco, enviar e-mail, etc.)

        return redirect()->to(base_url('cliente/contato_sucesso'));
    }

    public function sucesso()
    {
        return view('contato_sucesso');
    }
    
}
