<?php

namespace App\Controllers;

use App\Models\ClienteModel;

class Auth extends BaseController
{
    public function login()
    {
        return view('login_form');
    }

    public function autenticar()
    {
        $session = session();

        $email = $this->request->getPost('email');
        $senha = $this->request->getPost('senha');

        $userModel = new ClienteModel();
        $user = $userModel->where('email', $email)->first();

     

        if ($user && password_verify($senha, $user['senha'])) {
            $session->set('user_id', $user['id']);
            $session->set('user_email', $user['email']);
            $session->set('logado', true);

            return redirect()->to('/loja');
        }

        $session->setFlashdata('erro', 'Email ou senha incorretos.');
        return redirect()->to('/auth/login');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/auth/login');
    }
}
