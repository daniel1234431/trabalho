<?php

namespace App\Controllers;

use App\Models\DadosBoletoModel;
use CodeIgniter\Controller;

class DadosBoleto extends Controller
{
    protected $dadosBoletoModel;

    public function __construct()
    {
        $this->dadosBoletoModel = new DadosBoletoModel();
    }

    public function salvar()
    {
        $data = [
            'nome_pagador' => $this->request->getPost('nome_pagador'),
            'cpf_cnpj' => $this->request->getPost('cpf_cnpj'),
            'valor' => $this->request->getPost('valor'),
            'data_vencimento' => $this->request->getPost('data_vencimento'),
        ];

        if ($this->dadosBoletoModel->insert($data)) {
            return redirect()->to('/boleto/sucesso');
        } else {
            return redirect()->back()->with('error', 'Erro ao salvar dados do boleto.');
        }
    }

    public function sucesso()
    {
        echo "Dados do boleto salvos com sucesso!";
    }
}
