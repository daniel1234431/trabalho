<?php

namespace App\Controllers;

class Loja extends BaseController
{
    public function index()
    {
        return view('loja'); // chama a view app/Views/loja.php
    }
}
