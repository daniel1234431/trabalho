<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\DadosCartaoModel;

class DadosCartao extends Controller
{
    protected $dadosCartaoModel;

    public function __construct()
    {
        $this->dadosCartaoModel = new DadosCartaoModel();
    }

    public function index()
    {
        echo view('dados_cartao/form');
    }

    public function salvar()
    {
        $session = session();

        $nome_cartao = $this->request->getPost('nome_cartao');
        $numero_cartao = $this->request->getPost('numero_cartao');
        $validade = $this->request->getPost('validade');
        $cvv = $this->request->getPost('cvv');

        if (empty($nome_cartao) || empty($numero_cartao) || empty($validade) || empty($cvv)) {
            $session->setFlashdata('error', 'Por favor, preencha todos os campos.');
            return redirect()->to('/dadoscartao');
        }

        // Salva no banco de dados
        $this->dadosCartaoModel->save([
            'nome_cartao' => $nome_cartao,
            'numero_cartao' => $numero_cartao,
            'validade' => $validade,
            'cvv' => $cvv,
        ]);

        $session->setFlashdata('success', 'Dados do cartão salvos com sucesso!');
        return redirect()->to('/dadoscartao/visualizar');
    }

    public function visualizar()
    {
        $session = session();

     
        $dados = $this->dadosCartaoModel->orderBy('id', 'DESC')->first();

        if (!$dados) {
            return redirect()->to('/dadoscartao')->with('error', 'Nenhum dado de cartão salvo.');
        }

        return view('dados_cartao/visualizar', ['dados' => $dados]);
    }
}
