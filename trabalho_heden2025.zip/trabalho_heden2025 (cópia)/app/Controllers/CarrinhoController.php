<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class CarrinhoController extends Controller
{
   
    public function index()
    {
       
        $carrinho = session()->get('carrinho') ?? [];
        echo view('cliente/Carrinho', ['carrinho' => $carrinho]);
    }

   
    public function adicionar($produtoId)
    {
       
        $produto = $this->getProdutoPorId($produtoId);
        
        if ($produto) {
           
            $carrinho = session()->get('carrinho') ?? [];

            
            $carrinho[] = [
                'id' => $produto['id'],
                'nome' => $produto['nome'],
                'preco' => $produto['preco'],
                'quantidade' => 1 
            ];

            
            session()->set('carrinho', $carrinho);
        }

       
        return redirect()->to('/cliente/carrinho');
    }

    
    private function getProdutoPorId($id)
    {
        
        $produtos = [
            1 => ['id' => 1, 'nome' => 'Perfume', 'preco' => 100],
            2 => ['id' => 2, 'nome' => 'Camiseta', 'preco' => 50],
            3 => ['id' => 3, 'nome' => 'Sabonete', 'preco' => 25],
            4 => ['id' => 4, 'nome' => 'Esfoliante', 'preco' => 30],
            
        ];

        return $produtos[$id] ?? null;
    }
}
