<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        /* Reset básico */
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        /* Corpo da página */
        body {
          font-family: Arial, sans-serif;
          background: linear-gradient(to right, #a8e063, #56ab2f); /* Gradiente verde moderno */
          min-height: 100vh;
          display: flex;
          justify-content: center;
          align-items: center;
        }

        /* Container do formulário */
        .form-container {
          background-color: #ffffffee;
          padding: 30px;
          border-radius: 15px;
          box-shadow: 0 8px 16px rgba(0,0,0,0.1);
          width: 100%;
          max-width: 400px;
          box-shadow: 0 6px 10px rgba(0,0,0,0.3);
          animation: fadeIn 0.6s ease-in-out;
          transition: 
            background-color 0.3s ease, 
            transform 0.2s ease, 
            box-shadow 0.3s ease, 
            filter 0.3s ease;
          box-shadow: 0 4px 6px rgba(0,0,0,0.9);
        }

        /* Título */
        .titl {
          text-align: center;
          font-size: 28px;
          color: #2e7d32;
          margin-bottom: 25px;
        }

        /* Campos do formulário */
        .form-group {
          margin-bottom: 20px;
        }

        label {
          display: block;
          margin-bottom: 6px;
          font-weight: bold;
          color: #333;
        }

        input[type="email"],
        input[type="password"] {
          width: 100%;
          padding: 12px;
          border: 1px solid #ccc;
          border-radius: 8px;
          box-sizing: border-box;
          transition: all 0.3s;
          box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        input[type="email"]:focus,
        input[type="password"]:focus {
          border-color: #4CAF50;
          outline: none;
          box-shadow: 0 0 0 3px rgba(76, 175, 80, 0.2);
        }

        /* Botão principal */
        .btn-login {
          width: 100%;
          padding: 12px;
          background-color: #4CAF50;
          color: white;
          border: none;
          font-size: 16px;
          cursor: pointer;
          border-radius: 8px;
          transition: all 0.3s;
          box-shadow: 0 4px 6px rgba(0,0,0,0.1);
          margin-top: 10px;
        }

        .btn-login:hover {
          background-color: #388e3c;
          transform: translateY(-2px);
          box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }

        /* Links extras */
        .link-extra {
          text-align: center;
          margin-top: 20px;
        }

        .link-extra a {
          text-decoration: none;
          color: #007bff;
          font-weight: bold;
          transition: color 0.3s;
        }

        .link-extra a:hover {
          color: #0056b3;
          text-decoration: underline;
        }

        /* Mensagem de erro */
        .error-message {
          color: #d32f2f;
          background-color: #fde0e0;
          padding: 12px;
          border-radius: 8px;
          margin-bottom: 20px;
          text-align: center;
          font-size: 14px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        /* Texto no topo */
        .top-text {
          position: absolute;
          top: 15px;
          left: 15px;
          z-index: 999;
          background-color: rgba(255, 255, 255, 0.85);
          padding: 8px 20px;
          border-radius: 10px;
          box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .top-text h3 {
          margin: 0;
          font-size: 1rem;
          font-weight: normal;
        }

        /* Rodapé */
        .footer {
          background-color: black;
          color: white;
          text-align: center;
          padding: 10px;
          position: fixed;
          bottom: 0;
          width: 100%;
        }

        /* Animação */
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        /* Responsivo */
        @media (max-width: 500px) {
          .form-container {
            padding: 20px;
          }
          
          .titl {
            font-size: 24px;
          }
        }
    </style>
</head>
<body>
  
<div class="top-text">
  <h3><small class="text-body-secondary"> ARTESANA</small></h3>
</div>

<div class="form-container">
    <h1 class="titl">Login</h1>

    <?php if (session()->getFlashdata('erro')): ?>
        <p class="error-message"><?= session()->getFlashdata('erro') ?></p>
    <?php endif; ?>

    <form method="post" action="/auth/autenticar">
        <!-- Campo Email -->
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" placeholder="nome@gmail.com" required>
        </div>
        
        <!-- Campo Senha -->
        <div class="form-group">
            <label for="senha">Senha:</label>
            <input type="password" name="senha" id="senha" placeholder="Digite sua senha" required>
        </div>
        
        <!-- Botão de Login -->
        <button type="submit" class="btn-login">Entrar</button>
    </form>

    <!-- Link para cadastro -->
    <div class="link-extra">
        <p>Não tem uma conta? <a href="/cliente/cadastro">Cadastre-se</a></p>
    </div>

    <!-- Link para recuperação de senha -->
    <div class="link-extra">
        <p>Esqueceu sua senha? <a href="/recuperar-senha">Recuperar senha</a></p>
    </div>
</div>

<div class="footer">
    &copy; 2025 Artesana. Todos os direitos reservados.
</div>
</body>
</html>