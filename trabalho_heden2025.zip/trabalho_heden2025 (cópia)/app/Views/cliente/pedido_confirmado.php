<style>
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ccc;
        padding: 10px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }

    h2, h3 {
        margin-top: 20px;
        color: #333;
    }

    a {
        display: inline-block;
        margin-top: 15px;
        text-decoration: none;
        color: #fff;
        background-color: #007bff;
        padding: 10px 15px;
        border-radius: 5px;
    }

    a:hover {
        background-color: #0056b3;
    }
</style>

<h2>Obrigado pela sua compra!</h2>
<p>Seu pedido foi confirmado com sucesso.</p>
<a href="<?= base_url('cliente/index') ?>">Voltar à loja</a>

<h2>Pedido Confirmado!</h2>

<?php if (!empty($produtos)): ?>
    <h3>Produtos comprados:</h3>
    <table>
        <thead>
            <tr>
                <th>Produto</th>
                <th>Quantidade</th>
                <th>Preço Unitário</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($produtos as $produto): ?>
                <tr>
                    <td><?= esc($produto['nome']) ?></td>
                    <td><?= esc($produto['quantidade']) ?></td>
                    <td>R$ <?= number_format($produto['preco'], 1, ',', '.') ?></td>
                    <td>R$ <?= number_format($produto['preco'] * $produto['quantidade'], 1, ',', '.') ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p>Nenhum produto encontrado no pedido.</p>
<?php endif; ?>
