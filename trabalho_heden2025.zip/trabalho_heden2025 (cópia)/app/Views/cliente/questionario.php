<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Quiz de Sustentabilidade</title>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      background: linear-gradient(to right, #a8e063, #56ab2f);
      margin: 0;
      padding: 0;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

header {
  background-color: #2E7D32;
  padding: 20px;
  text-align: center;
  color: white;
}

header nav a {
  color: white;
  margin: 0 15px;
  text-decoration: none;
  font-weight: bold;
}

header nav a:hover {
  text-decoration: underline;
}

    .quiz-container {
      margin-top:150px;
      background-color: #fff;
      max-width: 600px;
      width: 90%;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
    }

    h1 {
      text-align: center;
      color: #2e7d32;
      margin-bottom: 20px;
    }

    .question {
      margin-bottom: 20px;
    }

    .question h3 {
      font-size: 18px;
      margin-bottom: 10px;
      color: #333;
    }

    .question label {
      display: block;
      margin-bottom: 8px;
    }

    .submit-btn {
      display: block;
      width: 100%;
      background: #4CAF50;
      color: white;
      border: none;
      padding: 12px;
      font-size: 16px;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .submit-btn:hover {
      background: #388e3c;
    }

    .button-container {
      text-align: center;
      margin-top: 15px;
    }

    .btn-info {
      text-align: right;
      background-color: #3498db;
      color: white;
      padding: 10px 15px;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      transition: background-color 0.3s;
    }

    .btvolt {
      position: absolute;
      top: 20px;
      left: 20px;
      z-index: 1000;
    }
    
    /* Responsivo */
    @media (max-width: 768px) {
      .menu-toggle {
        display: block;
      }

      .menu-items {
        position: fixed;
        top: 70px;
        left: -100%;
        width: 80%;
        height: calc(100vh - 70px);
        background-color: var(--verde-escuro);
        flex-direction: column;
        transition: all 0.5s ease;
        box-shadow: 2px 0 5px var(--sombra);
      }

      .menu-items.active {
        left: 0;
      }

      .menu-items li {
        width: 100%;
      }

      .menu-items a {
        padding: 15px 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }

      .main-content {
        padding-top: 70px;
      }

      .container {
        margin: 15px;
        padding: 20px;
      }
    }
        :root {
      --verde-esmeralda: #43A047;
      --verde-principal: #2E7D32;
      --verde-escuro: #014421;
      --branco: #FFFFFF;
      --sombra: rgba(0,0,0,0.2);
    }

    /* Animações */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.05); }
      100% { transform: scale(1); }
    }

    @keyframes bounce {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-5px); }
    }

    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-5px); }
      75% { transform: translateX(5px); }
    }

    @keyframes slideDown {
      from { transform: translateY(-100%); }
      to { transform: translateY(0); }
    }

    /* Estilos Gerais */
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      padding: 0;
      margin: 0;
      background-color: #d0f0c0;
      color: #424242;
      background-image: url('/fnd2.jpg');
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center;
      transition: opacity 0.9s ease;
    }

    /* Menu Superior Aprimorado */
    .header {
      background-color: var(--verde-escuro);
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
      box-shadow: 0 4px 12px var(--sombra);
      animation: slideDown 0.5s ease-out;
    }

    .nav-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
      max-width: 1400px;
      margin: 0 auto;
    }

    .logo {
      display: flex;
      align-items: center;
      color: var(--branco);
      text-decoration: none;
      font-weight: bold;
      font-size: 1.5rem;
      padding: 15px 0;
    }

    .logo img {
      height: 40px;
      margin-right: 10px;
    }

    .menu-toggle {
      display: none;
      background: none;
      border: none;
      color: var(--branco);
      font-size: 1.5rem;
      cursor: pointer;
    }

    .menu-items {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .menu-items li {
      position: relative;
    }

    .menu-items a {
      color: var(--branco);
      text-decoration: none;
      padding: 20px 15px;
      display: block;
      font-weight: 500;
      transition: all 0.3s ease;
      position: relative;
    }

    .menu-items a:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .menu-items a::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      width: 0;
      height: 3px;
      background: var(--branco);
      transition: all 0.3s ease;
      transform: translateX(-50%);
    }

    .menu-items a:hover::after {
      width: 80%;
    }

    .menu-items i {
      margin-right: 8px;
    }

    /* Conteúdo Principal */
    .main-content {
      padding-top: 80px;
      padding-bottom: 60px;
    }

    /* Restante do seu CSS existente */
    .container-wrapper {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 30px;
      margin: 40px auto;
      max-width: 1400px;
      transition: 
        background-color 0.3s ease, 
        transform 0.2s ease, 
        box-shadow 0.3s ease, 
        filter 0.3s ease;
      box-shadow: 0 4px 6px rgba(0,0,0,0.9);
      animation: fadeIn 0.6s ease-in-out;
    }

    .container {
      flex: 1 1 400px;
      max-width: 500px;
      background-color: rgba(255, 255, 255, 0.85);
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 6px 10px rgba(0,0,0,0.3);
      animation: fadeIn 0.6s ease-in-out;
      transition: 
        background-color 0.3s ease, 
        transform 0.2s ease, 
        box-shadow 0.3s ease, 
        filter 0.3s ease;
    }

    .titulo1 {
      font-size: 24px;
      color: var(--verde-escuro);
      margin-bottom: 15px;
    }

    .btn {
      background-color: var(--verde-escuro);
      color: white;
      padding: 12px 24px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-weight: bold;
      text-decoration: none;
      display: inline-block;
      transition: all 0.3s ease;
      box-shadow: 0 4px 6px rgba(0,0,0,0.3);
      animation: fadeIn 0.6s ease-in-out;
      position: relative;
      overflow: hidden;
    }

    .btn:hover {
      background-color: var(--verde-esmeralda);
      transform: translateY(-3px);
      box-shadow: 0 6px 12px rgba(0,0,0,0.2);
      animation: bounce 0.5s ease;
    }

    .btn:active {
      transform: translateY(1px);
    }

    .btn::after {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      width: 5px;
      height: 5px;
      background: rgba(255, 255, 255, 0.5);
      opacity: 0;
      border-radius: 100%;
      transform: scale(1, 1) translate(-50%);
      transform-origin: 50% 50%;
    }

    .button-container .btn {
      width: 100%;
      margin-top: 15px;
    }

    form input[type="email"],
    form input[type="text"] {
      padding: 12px;
      width: 100%;
      border-radius: 8px;
      border: 1px solid #ccc;
      margin-bottom: 15px;
      transition: all 0.3s ease;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    /* Rodapé */
    .footer {
      text-align: center;
      padding: 20px;
      font-weight: bold;
      color: white;
      background-color: var(--verde-escuro);
      border-top: 4px solid #81C784;
      animation: fadeIn 0.8s ease-in-out;
      position: fixed;
      bottom: 0;
      width: 100%;
    }
  </style>
</head>
<body>

<header class="header">
  <div class="nav-container">
    <a href="<?=base_url('cliente/index')?>" class="logo">
      <i data-lucide="leaf"></i> Artesana
    </a>
    <button class="menu-toggle" id="menuToggle">
      <i data-lucide="menu"></i>
    </button>
    <ul class="menu-items" id="menuItems">
      <li><a href="<?=base_url('cliente/index')?>"><i data-lucide="home"></i> Início</a></li>
      <li><a href="<?=base_url('cliente/sobre')?>"><i data-lucide="info"></i> Sobre</a></li>
      <li><a href="<?=base_url('cliente/serviços')?>"><i data-lucide="briefcase"></i> Serviços</a></li>
      <li><a href="<?=base_url('cliente/produtos')?>"><i data-lucide="shopping-bag"></i> Produtos</a></li>
      <li><a href="<?=base_url('cliente/contato')?>"><i data-lucide="mail"></i> Contato</a></li>
      <li><a href="<?=base_url('Cliente/login')?>" class="btn"><i data-lucide="log-in"></i> Login</a></li>
    </ul>
  </div>
</header>

<div class="quiz-container">
  <h1>Quiz: Sustentabilidade</h1>
  <form id="quiz-form" method="post" action="<?= base_url('cliente/resultado_quiz') ?>">

    <?php
    $perguntas = [
      '1. O que significa desenvolvimento sustentável?' => [
        'Crescimento econômico ilimitado' => 'errado',
        'Utilizar os recursos naturais de forma consciente' => 'certo',
        'Expandir cidades e indústrias' => 'errado'
      ],
      '2. Qual desses materiais é reciclável?' => [
        'Plástico' => 'certo',
        'Comida' => 'errado',
        'Tecido sujo' => 'errado'
      ],
      '3. Qual é a principal fonte de energia renovável no Brasil?' => [
        'Carvão mineral' => 'errado',
        'Hidrelétrica' => 'certo',
        'Petróleo' => 'errado'
      ],
      '4. Qual das alternativas reduz a emissão de CO₂?' => [
        'Usar mais o carro' => 'errado',
        'Plantar árvores' => 'certo',
        'Desmatar florestas' => 'errado'
      ],
      '5. O que é a compostagem?' => [
        'Método de queima de lixo' => 'errado',
        'Processo de transformar resíduos orgânicos em adubo' => 'certo',
        'Armazenamento de lixo em lixões' => 'errado'
      ],
      '6. Qual ação ajuda a preservar a água potável?' => [
        'Lavar calçadas com mangueira' => 'errado',
        'Consertar vazamentos' => 'certo',
        'Deixar torneiras abertas' => 'errado'
      ],
      '7. O que significa "pegada de carbono"?' => [
        'O número de pegadas em uma trilha' => 'errado',
        'Quantidade de carbono emitida por uma pessoa, empresa ou produto' => 'certo',
        'O tipo de solo afetado pela poluição' => 'errado'
      ]
    ];

    $i = 1;
    foreach ($perguntas as $titulo => $respostas):
    ?>
    <div class="question">
      <h3><?= $i . '. ' . $titulo ?></h3>
      <?php foreach ($respostas as $texto => $valor): ?>
        <label>
          <input type="radio" name="q<?= $i ?>" value="<?= $valor ?>"> <?= $texto ?>
        </label>
      <?php endforeach; ?>
    </div>
    <?php $i++; endforeach; ?>

    <!-- Início do formulário -->
    <form action="<?= site_url('quiz/avaliar') ?>" method="post">
  <!-- Perguntas e alternativas aqui -->

  <div class="text-center mt-4">
    <button type="submit" class="btn btn-success">Enviar Respostas</button>
  </div>
</form>
</form>

  </form>
</div>

<script>
  document.getElementById('quiz-form').addEventListener('submit', function (e) {
    const requiredQuestions = ['q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7'];
    let allAnswered = true;

    for (const question of requiredQuestions) {
      const options = document.getElementsByName(question);
      const isChecked = Array.from(options).some(option => option.checked);
      if (!isChecked) {
        allAnswered = false;
        break;
      }
    }

    if (!allAnswered) {
      e.preventDefault();
      alert("Por favor, responda todas as perguntas antes de enviar.");
    }
  });
</script>

</body>
</html>
