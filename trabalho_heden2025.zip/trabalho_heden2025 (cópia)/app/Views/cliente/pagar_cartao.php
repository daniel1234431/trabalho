<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Pagamento com Cartão</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(to right, #f9fbe7, #ffffff);
      padding: 40px;
      color: #2c3e50;
    }

    .container-form {
      background-color: #ffffff;
      max-width: 500px;
      margin: 0 auto;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      font-weight: bold;
      margin-bottom: 15px;
    }

    p {
      color: #555;
      margin-bottom: 25px;
      text-align: center;
    }

    label {
      font-weight: 600;
      margin-top: 15px;
      display: block;
    }

    input[type="text"] {
      width: 100%;
      padding: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
      margin-top: 8px;
    }

    button, .btn-voltar, .btn-info {
      width: 100%;
      padding: 12px;
      font-size: 16px;
      border-radius: 8px;
      margin-top: 15px;
    }

    button {
      background-color: #2e7d32;
      color: #fff;
      border: none;
    }

    button:hover {
      background-color: #256428;
    }

    .btn-voltar {
      background-color: #4CAF50;
      color: white;
      border: none;
      
     
    }

    .btn-voltar:hover {
      background-color: #388e3c;
      transform: translateY(-2px);
      box-shadow: 0 6px 12px rgba(0,0,0,0.15);
    }

    .btn-info {
      background-color: #3498db;
      border: none;
      color: white;
      text-decoration: none;
    }

    .btn-info:hover {
      background-color: #2980b9;
    }
    .btvolt{
        
      text-align: left;
    margin-bottom: 20px;
        margin-bottom: 20px;
        margin-right:1600px;
    }
    .btn-voltar {
      background-color: #4CAF50;
      color: white;
      border: none;
      padding: 10px 15px;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      transition: background-color 0.3s, transform 0.3s, box-shadow 0.3s;
    }

  .btn-info {
    background-color: #3498db;
    color: white;
    padding: 10px 15px;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
    transition: background-color 0.3s;
  }

  .btn-info:hover {
    background-color: #2980b9;
  }
  </style>
</head>
<body>

  <div class="btvolt">
    <?= anchor('Cliente/pagar', '← Voltar', ['class' => 'btn btn-info']) ?>
  </div>

  <div class="container-form">
    <h2>💳 Pagamento com Cartão de Crédito</h2>
    <p>Preencha os dados abaixo para efetuar o pagamento.</p>

    <form id="formPagamento" method="POST" action="<?= base_url('cliente/salvar_cartao') ?>">

      <label for="nome_cartao">Nome no Cartão:</label>
      <input type="text" name="nome_cartao" id="nome_cartao" required>

      <label for="numero_cartao">Número do Cartão:</label>
      <input type="text" name="numero_cartao" id="numero_cartao" required>

      <label for="validade">Data de Validade:</label>
      <input type="text" name="validade" id="validade" placeholder="MM/AA" required>

      <label for="cvv">CVV:</label>
      <input type="text" name="cvv" id="cvv" required>

     
      <button type="submit" id="btnContinuar">Continuar</button>
    </form>
  </div>

  
  <!-- campos -->
  


<script>
  document.getElementById('formPagamento').addEventListener('submit', function(event) {
    const nome = document.getElementById('nome_cartao').value.trim();
    const numero = document.getElementById('numero_cartao').value.trim();
    const validade = document.getElementById('validade').value.trim();
    const cvv = document.getElementById('cvv').value.trim();

    if (!nome || !numero || !validade || !cvv) {
      event.preventDefault(); // evita o envio do form
      alert("Por favor, preencha todos os campos antes de continuar.");
    }
  });
</script>



</body>
</html>
