<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Mensagem Enviada</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f0f4f7;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .mensagem {
      background: white;
      padding: 40px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      text-align: center;
    }
    .mensagem h1 {
      color: #2E7D32;
    }
    .mensagem a {
      display: inline-block;
      margin-top: 20px;
      color: #fff;
      background-color: #2E7D32;
      padding: 10px 20px;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
    }
    .mensagem a:hover {
      background-color: #1b5e20;
    }
  </style>
</head>
<body>
  <div class="mensagem">
    <h1>✅ Mensagem enviada com sucesso!</h1>
    <p>Obrigado por entrar em contato. Retornaremos em breve.</p>
    <a href="<?= base_url('cliente/contato') ?>">Voltar</a>
  </div>
</body>
</html>
