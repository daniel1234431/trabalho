<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Galeria de Vídeos</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 20px;
    }

    h1 {
      text-align: center;
      color: #333;
    }

    .video-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 20px;
      margin-top: 30px;
      max-width: 1200px;
      margin-left: auto;
      margin-right: auto;
    }

    .video {
      background-color: #fff;
      padding: 10px;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    iframe {
      width: 100%;
      height: 200px;
      border: none;
      border-radius: 8px;
    }

    @media (min-width: 768px) {
      iframe {
        height: 250px;
      }
    }
  </style>
</head>
<body>
  <h1>Minha Galeria de Vídeos</h1>

  <div class="video-container">
    <div class="video">
      <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" allowfullscreen></iframe>
    </div>
    <div class="video">
      <iframe src="https://www.youtube.com/embed/3JZ_D3ELwOQ" allowfullscreen></iframe>
    </div>
    <!-- Adicione mais vídeos copiando o bloco abaixo -->
    <!--
    <div class="video">
      <iframe src="URL_DO_VIDEO_AQUI" allowfullscreen></iframe>
    </div>
    -->
  </div>
</body>
</html>
