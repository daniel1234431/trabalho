<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Formulário de Entrega de Pedido</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 30px;
      background-color: #f5f5f5;
    }
    form {
      background-color: #fff;
      padding: 20px;
      border-radius: 8px;
      max-width: 600px;
      margin: auto;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }
    label {
      display: block;
      margin-top: 15px;
    }
    input, textarea, select {
      width: 100%;
      padding: 8px;
      margin-top: 5px;
      border-radius: 20px;
      border: 1px solid #ccc;
    }
    button {
      margin-top: 20px;
      padding: 10px 20px;
      background-color: #2d89ef;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
    }
    button:hover {
      background-color: #1b61c1;
    }
    h2 {
      text-align: center;
      color: #333;
    }
    .btn-container {
      text-align: center;
    }
    :root {
      --verde-esmeralda: #43A047;
      --verde-principal: #2E7D32;
      --verde-escuro: #014421;
      --branco: #FFFFFF;
      --sombra: rgba(0,0,0,0.2);
    }

    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-5px); }
      75% { transform: translateX(5px); }
    }

    @keyframes slideDown {
      from { transform: translateY(-100%); }
      to { transform: translateY(0); }
    }

    html, body {
      min-height: 100vh;
  height: 100%;
  margin: 0;
  padding: 0;
}
@media (max-width: 768px) {
      .menu-toggle {
        display: block;
      }

      .menu-items {
        position: fixed;
        top: 70px;
        left: -100%;
        width: 80%;
        height: calc(100vh - 70px);
        background-color: var(--verde-escuro);
        flex-direction: column;
        transition: all 0.5s ease;
        box-shadow: 2px 0 5px var(--sombra);
      }

      .menu-items.active {
        left: 0;
      }

      .menu-items li {
        width: 100%;
      }

      .menu-items a {
        padding: 15px 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
      }

      .main-content {
        padding-top: 70px;
      }

      .container {
        margin: 15px;
        padding: 20px;
      }
    }
    .header {
      background-color: var(--verde-escuro);
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
      box-shadow: 0 4px 12px var(--sombra);
      animation: slideDown 0.5s ease-out;
    }

    .nav-container {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 20px;
      max-width: 1400px;
      margin: 0 auto;
    }

    .logo {
      display: flex;
      align-items: center;
      color: var(--branco);
      text-decoration: none;
      font-weight: bold;
      font-size: 1.5rem;
      padding: 15px 0;
    }

    .logo img {
      height: 40px;
      margin-right: 10px;
    }

    .menu-toggle {
      display: none;
      background: none;
      border: none;
      color: var(--branco);
      font-size: 1.5rem;
      cursor: pointer;
    }

    .menu-items {
      display: flex;
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .menu-items li {
      position: relative;
    }

    .menu-items a {
      color: var(--branco);
      text-decoration: none;
      padding: 20px 15px;
      display: block;
      font-weight: 500;
      transition: all 0.3s ease;
      position: relative;
    }

    .menu-items a:hover {
      background-color: rgba(255, 255, 255, 0.1);
    }

    .menu-items a::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      width: 0;
      height: 3px;
      background: var(--branco);
      transition: all 0.3s ease;
      transform: translateX(-50%);
    }

    .menu-items a:hover::after {
      width: 80%;
    }

    .menu-items i {
      margin-right: 8px;
    }

    /* Conteúdo Principal */
    .main-content {
      padding-top: 80px;
      padding-bottom: 60px;
    }

    /* Restante do seu CSS existente */
    .container-wrapper {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      gap: 30px;
      margin: 40px auto;
      max-width: 1400px;
      transition: 
        background-color 0.3s ease, 
        transform 0.2s ease, 
        box-shadow 0.3s ease, 
        filter 0.3s ease;
      box-shadow: 0 4px 6px rgba(0,0,0,0.9);
      animation: fadeIn 0.6s ease-in-out;
    }

    .container {
      flex: 1 1 400px;
      max-width: 500px;
      background-color: rgba(255, 255, 255, 0.85);
      border-radius: 15px;
      padding: 30px;
      box-shadow: 0 6px 10px rgba(0,0,0,0.3);
      animation: fadeIn 0.6s ease-in-out;
      transition: 
        background-color 0.3s ease, 
        transform 0.2s ease, 
        box-shadow 0.3s ease, 
        filter 0.3s ease;
    }
  </style>
</head>
<body>

<header class="header">
    <div class="nav-container">
      <a href="<?=base_url('cliente/index')?>" class="logo">
        <i data-lucide="leaf"></i> Artesana
      </a>
      
      <button class="menu-toggle" id="menuToggle">
        <i data-lucide="menu"></i>
      </button>
      
      <ul class="menu-items" id="menuItems">
        <li><a href="<?=base_url('cliente/index')?>"><i data-lucide="home"></i> Início</a></li>
        <li><a href="<?=base_url('cliente/sobre')?>"><i data-lucide="info"></i> Sobre</a></li>
        <li><a href="<?=base_url('cliente/serviços')?>"><i data-lucide="briefcase"></i> Serviços</a></li>
        <li><a href="<?=base_url('cliente/produtos')?>"><i data-lucide="shopping-bag"></i> Produtos</a></li>
        <li><a href="<?=base_url('cliente/contato')?>"><i data-lucide="mail"></i> Contato</a></li>
        <li><a href="<?=base_url('Cliente/login')?>" class="btn" style="margin: 10px;"><i data-lucide="log-in"></i> Login</a></li>
      </ul>
    </div>
  </header>

  <form id="pedidoForm" action="<?= base_url('cliente/confirmarPedido') ?>" method="post">

    <h2>Dados de confirmação de compra</h2>

   
    <label for="nome">Nome completo:</label>
    <input type="text" id="nome" name="nome" required>

    <label for="telefone">Telefone:</label>
    <input type="tel" id="telefone" name="telefone" required placeholder="(99) 99999-9999">

    <label for="email">E-mail:</label>
    <input type="email" id="email" name="email" required placeholder="exemplo@gmail.com">

    <label for="cep">CEP:</label>
    <input type="text" id="cep" name="cep" required>

    <label for="rua">Rua / Avenida:</label>
    <input type="text" id="rua" name="rua" required>

    <label for="numero">Número:</label>
    <input type="text" id="numero" name="numero" required placeholder="Numero da rua">

    <label for="complemento">Complemento:</label>
    <input type="text" id="complemento" name="complemento" placeholder="(campo opcional)">

    <label for="bairro">Bairro:</label>
    <input type="text" id="bairro" name="bairro" required>

    <label for="cidade">Cidade:</label>
    <input type="text" id="cidade" name="cidade" required>

    <label for="estado">Estado (UF):</label>
    <select id="estado" name="estado" required>
      <option value="" disabled selectd>Selecione um estado</option>
      <option value="AC">Acre</option>
        <option value="AL">Alagoas</option>
        <option value="AP">Amapá</option>
        <option value="AM">Amazonas</option>
        <option value="BA">Bahia</option>
        <option value="CE">Ceará</option>
        <option value="DF">Distrito Federal</option>
        <option value="ES">Espírito Santo</option>
        <option value="GO">Goiás</option>
        <option value="MA">Maranhão</option>
        <option value="MT">Mato Grosso</option>
        <option value="MS">Mato Grosso do Sul</option>
        <option value="MG">Minas Gerais</option>
        <option value="PA">Pará</option>
        <option value="PB">Paraíba</option>
        <option value="PR">Paraná</option>
        <option value="PE">Pernambuco</option>
        <option value="PI">Piauí</option>
        <option value="RJ">Rio de Janeiro</option>
        <option value="RN">Rio Grande do Norte</option>
        <option value="RS">Rio Grande do Sul</option>
        <option value="RO">Rondônia</option>
        <option value="RR">Roraima</option>
        <option value="SC">Santa Catarina</option>
        <option value="SP">São Paulo</option>
        <option value="SE">Sergipe</option>
        <option value="TO">Tocantins</option>
      
    </select>

    <label for="referencia">Ponto de referência:</label>
    <input type="text" id="referencia" name="referencia" placeholder="(campo opcional)">

    <label for="observacoes">Comentário:</label>
    <textarea id="observacoes" name="observacoes" rows="4" placeholder="(campo opcional)"></textarea>
    <div id="passwordHelpBlock" class="form-text">
      
      <strong>Observação:</strong> O prazo de entrega é de 3 dias úteis.
                </div>
    <div class="btn-container">
      <button type="submit" class="btn00">Confirmar Pedido</button>
      <button type="button" class="btn01" onclick="window.location.href='<?= base_url('cliente/carrinho') ?>'">Cancelar Pedido</button>
    </div>
  </form>

  <script>
    document.getElementById('pedidoForm').addEventListener('submit', function (e) {
      e.preventDefault(); // Impede o envio imediato do formulário

      // Verifica se todos os campos obrigatórios foram preenchidos
      const requiredFields = ['nome', 'telefone', 'email', 'cep', 'rua', 'numero', 'bairro', 'cidade', 'estado'];
      let allFilled = true;

      for (const field of requiredFields) {
        const value = document.getElementById(field).value.trim();
        if (!value) {
          allFilled = false;
          break;
        }
      }

      if (allFilled) {
        alert("Compra concluída com sucesso, seu pedido chegará em breve!!.");
        this.submit();
      } else {
        alert("Por favor, preencha todos os campos obrigatórios antes de continuar.");
      }
    });
  </script>
</body>
</html>
