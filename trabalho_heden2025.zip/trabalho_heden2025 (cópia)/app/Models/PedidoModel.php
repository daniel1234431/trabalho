<?php

namespace App\Models;

use CodeIgniter\Model;

class PedidoModel extends Model
{
    protected $table = 'pedidos'; 
    protected $primaryKey = 'id';

    protected $allowedFields = [
        'nome', 'telefone', 'email', 'cep', 'rua', 'numero',
        'complemento', 'bairro', 'cidade', 'estado', 'referencia', 'observacoes'
    ];
}
