<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'cliente'; // ou o nome real da sua tabela
    protected $primaryKey = 'id';
    protected $allowedFields = ['email', 'senha'];
}
