<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class CarrinhoController extends Controller
{
    // Exibe a página do carrinho
    public function index()
    {
        // Recupera os itens do carrinho da sessão
        $carrinho = session()->get('carrinho') ?? [];
        echo view('cliente/Carrinho', ['carrinho' => $carrinho]);
    }

    // Adiciona um produto específico ao carrinho
    public function adicionar($produtoId)
    {
        // Recupera o produto a ser adicionado (simulação de banco de dados)
        $produto = $this->getProdutoPorId($produtoId);
        
        if ($produto) {
            // Recupera os itens existentes no carrinho
            $carrinho = session()->get('carrinho') ?? [];

            // Adiciona o produto ao carrinho, criando uma nova entrada
            $carrinho[] = [
                'id' => $produto['id'],
                'nome' => $produto['nome'],
                'preco' => $produto['preco'],
                'quantidade' => 1 // Inicializa a quantidade como 1
            ];

            // Atualiza a sessão com o novo carrinho
            session()->set('carrinho', $carrinho);
        }

        // Redireciona para o carrinho para que o usuário possa ver os produtos
        return redirect()->to('/cliente/carrinho');
    }

    // Função simulada para obter um produto pelo ID
    private function getProdutoPorId($id)
    {
        // Exemplo de produto (normalmente você obteria isso do banco de dados)
        $produtos = [
            1 => ['id' => 1, 'nome' => 'Perfume', 'preco' => 100],
            2 => ['id' => 2, 'nome' => 'Camiseta', 'preco' => 50],
            3 => ['id' => 3, 'nome' => 'Sabonete', 'preco' => 25],
            4 => ['id' => 4, 'nome' => 'Esfoliante', 'preco' => 30],
            // Adicione mais produtos conforme necessário
        ];

        return $produtos[$id] ?? null;
    }
}
