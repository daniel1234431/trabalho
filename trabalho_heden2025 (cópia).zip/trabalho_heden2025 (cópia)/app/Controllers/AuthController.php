<?php

namespace App\Controllers;

use App\Models\ClienteModel;
use CodeIgniter\Controller;

class AuthController extends BaseController
{
    public function login()
    {
        return view('auth/login');
    }

    public function autenticar()
    {
        $session = session();
        $model = new ClienteModel();

        $email = $this->request->getPost('email');
        $senha = $this->request->getPost('senha');

        $cliente = $model->where('email', $email)->first();

        if ($cliente && $cliente['senha'] === $senha) {
            $session->set([
                'cliente_id' => $cliente['id'],
                'cliente_nome' => $cliente['nome'],
                'logado' => true
            ]);
            return redirect()->to('/dashboard'); // Altere para sua página principal
        } else {
            return redirect()->back()->with('erro', 'Email ou senha inválidos');
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
