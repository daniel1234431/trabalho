<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\ClienteModel;

class Cliente extends BaseController
{
    private $clienteModel;

    public function __construct(){
        $this->clienteModel = new ClienteModel();
    }

    // exibir carrinho de compras
    public function Carrinho()
    {
        $session = session();
        $carrinho = $session->get('Carrinho') ?? [];
        
        echo view('_partials/header');
        echo view('cliente/Carrinho', ['Carrinho' => $carrinho]);
        echo view('_partials/footer');
    }

    public function adicionar($produto_id)
    {
        $session = session();

        
        $carrinho = $session->get('Carrinho') ?? [];

        // Produtos disponíveis
        $produtosDisponiveis = [
            1 => ['id' => 1, 'nome' => 'nome do produto', 'preco' => 99.99],
            2 => ['id' => 2, 'nome' => 'nome do produto', 'preco' => 119.90],
            3 => ['id' => 3, 'nome' => 'nome do produto', 'preco' => 79.99],
            4 => ['id' => 4, 'nome' => 'nome do produto', 'preco' => 89.90],
            5 => ['id' => 5, 'nome' => 'nome do produto', 'preco' => 119.90],
            6 => ['id' => 6, 'nome' => 'nome do produto', 'preco' => 99.90],
            7 => ['id' => 7, 'nome' => 'nome do produto', 'preco' => 79.99],
            8 => ['id' => 8, 'nome' => 'nome do produto', 'preco' => 89.90],
            9 => ['id' => 9, 'nome' => 'nome do produto', 'preco' => 119.90],
            10 => ['id' => 10, 'nome' => 'nome do produto', 'preco' => 99.90],
            11 => ['id' => 11, 'nome' => 'nome do produto', 'preco' => 79.99],
            12 => ['id' => 12, 'nome' => 'nome do produto', 'preco' => 89.90],
            13 => ['id' => 13, 'nome' => 'nome do produto', 'preco' => 119.90],
            14 => ['id' => 14, 'nome' => 'nome do produto', 'preco' => 99.90],
            15 => ['id' => 15, 'nome' => 'nome do produto', 'preco' => 79.99],
            16 => ['id' => 16, 'nome' => 'nome do produto', 'preco' => 89.90],
            17 => ['id' => 17, 'nome' => 'nome do produto', 'preco' => 119.90],
            18 => ['id' => 18, 'nome' => 'nome do produto', 'preco' => 99.90],
            19 => ['id' => 19, 'nome' => 'nome do produto', 'preco' => 79.99],
            20 => ['id' => 20, 'nome' => 'nome do produto', 'preco' => 89.90],
            21 => ['id' => 21, 'nome' => 'nome do produto', 'preco' => 119.90],
            22 => ['id' => 22, 'nome' => 'nome do produto', 'preco' => 99.90],
            23 => ['id' => 23, 'nome' => 'nome do produto', 'preco' => 79.99],
            24 => ['id' => 24, 'nome' => 'nome do produto', 'preco' => 89.90],
        ];

        // Se o produto existe na lista
        if (array_key_exists($produto_id, $produtosDisponiveis)) {
            // Se já está no carrinho, aumenta a quantidade
            if (isset($carrinho[$produto_id])) {
                $carrinho[$produto_id]['quantidade'] + 1;
            } else {
                $produto = $produtosDisponiveis[$produto_id];
                $produto['quantidade'] = 1;
                $carrinho[$produto_id] = $produto;
            }

            // Atualiza a sessão com o carrinho
            $session->set('Carrinho', $carrinho);

            // Exibe o carrinho para depuração
            var_dump($carrinho);  
        }

        return redirect()->to(base_url('cliente/Carrinho'));
    }

    public function limparCarrinho()
    {
        session()->remove('Carrinho');
        return redirect()->to('cliente/carrinho')->with('mensagem', 'Carrinho limpo com sucesso!');
    }

   


    // Formulário de cadastro de novo cliente
    public function novo(){
        return view('cliente/cadastro');
    }

    // Login do cliente
    public function login(){
        return view('cliente/login');
    }

    // Voltar para a loja
    public function voltar(){
        return view('cliente/loja');
    }
    
    // exibir perfumes
    public function perfumes(){
        echo view('_partials/header');
        echo view('cliente/perfumes');
        echo view('_partials/footer');
    }
    public function pagar_cartao(){
        echo view('_partials/header');
        echo view('cliente/pagar_cartao');
        echo view('_partials/footer');
    }
    public function processar_cartao(){
        echo view('_partials/header');
        echo view('cliente/processar_cartao');
        echo view('_partials/footer');
    }
    public function pagar_boleto(){
        echo view('_partials/header');
        echo view('cliente/pagar_boleto');
        echo view('_partials/footer');
    }
    public function pagar_pix(){
        echo view('_partials/header');
        echo view('cliente/pagar_pix');
        echo view('_partials/footer');
    }
    public function entrega_produto(){
        echo view('_partials/header');
        echo view('cliente/entrega_produto');
        echo view('_partials/footer');
    }
    public function gerar_boleto(){
        echo view('_partials/header');
        echo view('cliente/gerar_boleto');
        echo view('_partials/footer');
    }
   
    // exibir roupas
    public function roupas(){
        echo view('_partials/header');
        echo view('cliente/Roupas');
        echo view('_partials/footer');
    }
    //exibir historico de cliente
    public function historico(){
        echo view('_partials/header');
        echo view('cliente/historico');
        echo view('_partials/footer');
    }
    // pagina de pagamento
    public function pagar(){
        echo view('_partials/header');
        echo view('cliente/pagar');
        echo view('_partials/footer');
    }

    // exibir sabonetes
    public function Sabonetes(){
        echo view('_partials/header');
        echo view('cliente/Sabonetes');
        echo view('_partials/footer');
    }

    // exibir esfoliantes
    public function Esfoliantes(){
        echo view('_partials/header');
        echo view('cliente/Esfoliantes');
        echo view('_partials/footer');
    }

    // cremes e hidratantes
    public function Cremes_Hidratantes(){
        echo view('_partials/header');
        echo view('cliente/Cremes_Hidratantes');
        echo view('_partials/footer');
    }
    //cadastrar novo cliente
    public function cadastro(){
        echo view('_partials/header');
        echo view('cliente/cadastro');
        echo view('_partials/footer');
    }
    
    //inserir senha
    public function inserir(){
                                
    $dados = $this->request->getPost();

    if ($dados['senha'] !== $dados['confirma_senha']) {
        return redirect()->back()->withInput()->with('erro', 'As senhas não coincidem.');
    }

    unset($dados['confirma_senha']);

    $dados['senha'] = password_hash($dados['senha'], PASSWORD_DEFAULT);

    $this->clienteModel->save($dados);

    return redirect()->to('cliente/index')->with('sucesso', 'Cadastro realizado com sucesso!');
}

    
    // Editar dados do cliente
    public function editar($id){
        $cliente = $this->clienteModel->find($id);
        echo view('_partials/header');
        echo view('cliente/edita', [
            'cliente' => $cliente
        ]);
        echo view('_partials/footer');
    }

    // Atualizar dados do cliente
    public function atualizar($id){
        $cliente = $this->request->getPost();
        $this->clienteModel->update($id, $cliente);
        return redirect()->to('cliente/index');
    }

    // Excluir cliente
    public function excluir($id){
        $this->clienteModel->delete($id);
        return redirect()->to('cliente/index');
    }

    // Exibir loja
    public function loja(){
        echo view('_partials/header');
        echo view('cliente/loja');
        echo view('_partials/footer');
    }
    //e exibir carrinho de compra
    public function Compra(){
        echo view('_partials/header');
        echo view('cliente/Compra');
        echo view('_partials/footer');
    }
    //inicio da pagina
    public function index(){
        echo view('_partials/header');
        echo view('cliente/index');
        echo view('_partials/footer');
    }
    public function questionario(){
        echo view('_partials/header');
        echo view('cliente/questionario');
        echo view('_partials/footer');
    }
    public function tutorial(){
        echo view('_partials/header');
        echo view('cliente/tutorial');
        echo view('_partials/footer');
    }
    public function sobre(){
        echo view('_partials/header');
        echo view('cliente/sobre');
        echo view('_partials/footer');
    }
    public function serviços(){
        echo view('_partials/header');
        echo view('cliente/serviços');
        echo view('_partials/footer');
    }
    public function contato(){
        echo view('_partials/header');
        echo view('cliente/contato');
        echo view('_partials/footer');
    }
   

    // Controller Cliente.php
public function SalvarRespostas()
{
    $respostas_corretas = [
        'q1' => 'a',
        'q2' => 'b',
        'q3' => 'c',
        'q4' => 'a',
        'q5' => 'd',
        'q6' => 'b',
        'q7' => 'c',
    ];

    $acertos = 0;
    foreach ($respostas_corretas as $questao => $resposta_correta) {
        if ($this->request->getPost($questao) === $resposta_correta) {
            $acertos++;
        }
    }

    return view('resultado_quiz', ['acertos' => $acertos]);
}


    public function resultado_quiz(){
        echo view('_partials/header');
        echo view('cliente/resultado_quiz');
        echo view('_partials/footer');
    }
    


    // ir para a loja
    public function irloja(){
        return redirect()->to('cliente/loja');
    }

    // autenticar usuario ja cadastrado
    public function autenticar()
    {
        $email = $this->request->getPost('email');
        $senha = $this->request->getPost('senha');
    
        $cliente = $this->clienteModel->where('email', $email)->first();
    
        if ($cliente && password_verify($senha, $cliente['senha'])) {
            session()->set('cliente_nome', $cliente['nome']);
            return redirect()->to('cliente/login');
        } else {
            return redirect()->back()->with('erro', 'Email ou senha inválidos');
        }
    }
 
    
}
