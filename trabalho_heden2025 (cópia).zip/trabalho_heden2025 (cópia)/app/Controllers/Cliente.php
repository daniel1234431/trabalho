<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\ClienteModel;

class Cliente extends BaseController
{
    private $clienteModel;

    public function __construct(){
        $this->clienteModel = new ClienteModel();
    }

    public function index()
    {
        $clientes = $this->clienteModel->findall();
        echo view('_partials/header');
        echo view('cliente/index',[
            'clientes' => $clientes
        ]);
        echo view('_partials/footer');
    }

    public function novo(){
        return view('cliente/cadastro');
    }
    public function login(){
        return view('cliente/login');
    }
    public function voltar(){
        return view('cliente/loja');
    }
    public function perfumes(){
        return view('cliente/loja');
    }

    
   
    public function inserir(){
        $cliente = $this->request->getPost();
        $this->clienteModel->save($cliente);
        return redirect()->to('cliente/index');
    }
    


public function editar($id){
    $cliente = $this->clienteModel->find($id);
    echo view('_partials/header');
    echo view('cliente/edita',[
        'cliente' => $cliente
    ]);
    
    echo view('_partials/footer');
    
}
public function atualizar($id){
$cliente= $this-> request-> getPost();
$this->clienteModel->update($id, $cliente);
return redirect ()->to('cliente/index');
}
public function excluir ($id){
    $this->clienteModel->delete($id);
    return redirect()->to('cliente/index');

}
public function loja(){
    echo view('_partials/header');
    echo view('cliente/loja');
    echo view('_partials/footer');
}

public function irloja(){
    return redirect()->to('cliente/loja');
}




 
}