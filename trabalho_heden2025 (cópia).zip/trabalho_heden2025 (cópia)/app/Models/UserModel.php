<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'cliente'; // aqui mudou para sua tabela
    protected $primaryKey = 'id'; // confirma se a chave primária é 'id', se for outra, troca aqui

    protected $allowedFields = ['nome', 'email']; // ajusta os campos da sua tabela, ex: nome, email

    public function getUsers()
    {
        return $this->findAll();
    }
}



