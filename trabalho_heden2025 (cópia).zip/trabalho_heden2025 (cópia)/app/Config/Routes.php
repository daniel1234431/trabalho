<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Cliente::index');
$routes->setAutoRoute(true);
$routes->post('Cliente/google_callback', 'Cliente::google_callback');

$routes->post('/carrinho/adicionar', 'Carrinho::adicionar');
$routes->get('/carrinho/ver', 'Carrinho::ver');
$routes->get('/login', 'Auth::login');
$routes->post('/login', 'Auth::loginPost');
$routes->get('/logout', 'Auth::logout');
$routes->post('cliente/autenticar', 'Cliente::autenticar');
$routes->get('cliente/carrinho', 'CarrinhoController::index'); // Página do carrinho
$routes->get('cliente/carrinho/adicionar/(:num)', 'CarrinhoController::adicionar/$1'); // Adicionar produto
$routes->get('qr-code', 'QrCode::gerar');
$routes->get('/login', 'AuthController::login');
$routes->post('/autenticar', 'AuthController::autenticar');
$routes->get('/logout', 'AuthController::logout');
$routes->get('/dashboard', 'Dashboard::index', ['filter' => 'auth']);
$routes->get('/perfil', 'Usuario::perfil', ['filter' => 'auth']);





