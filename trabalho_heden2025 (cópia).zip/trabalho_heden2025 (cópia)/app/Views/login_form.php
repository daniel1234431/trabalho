<?php if (session()->getFlashdata('erro')): ?>
    <p style="color:red"><?= session()->getFlashdata('erro') ?></p>
<?php endif; ?>

<form method="post" action="/login/autenticar">
    Email: <input type="email" name="email"><br>
    Senha: <input type="password" name="senha"><br>
    <button type="submit">Entrar</button>
</form>
