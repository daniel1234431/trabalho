<style>
/* Reset básico */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Arial', sans-serif;
  background-color: #F5F3EF; /* Fundo igual ao da outra página */
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}


/* Paleta expandida de verdes */
:root {
  --verde-principal: #4CAF50;
  --verde-escuro: #2e7d32;
  --verde-oliva: #3e8e41;
  --verde-musgo: #7cb342;
  --verde-esmeralda: #2ecc71;
  --verde-lima: #aeea00;
  --verde-menta: #b2fab4;
}

/* Container principal */
.container, .container1 {
  background-color: #ffffffee;
  padding: 30px;
  margin: 20px auto;
  border-radius: 15px;
  box-shadow: 0 8px 16px rgba(0,0,0,0.1);
  max-width: 400px;
  text-align: center;
}

/* Título */
.titulo1 {
  font-size: 32px;
  color: var(--verde-escuro);
  margin-bottom: 25px;
}


.button-container {
  margin-top: 15px;
}

.button-container a {
  display: inline-block;
  text-decoration: none;
  color: white;
  background: linear-gradient(45deg, var(--verde-esmeralda), var(--verde-principal));
  padding: 12px 25px;
  border-radius: 8px;
  font-size: 16px;
  font-weight: bold;
  transition: 
    background-color 0.3s ease, 
    transform 0.2s ease, 
    box-shadow 0.3s ease, 
    filter 0.3s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
  animation: fadeIn 0.6s ease-in-out;
}

.button-container a:hover {
  background: linear-gradient(45deg, var(--verde-lima), var(--verde-oliva));
  transform: translateY(-3px);
  box-shadow: 0 8px 16px rgba(0,0,0,0.2);
  filter: brightness(1.05);
}


.top-buttons .btn:hover {
  background: linear-gradient(45deg, var(--verde-lima), var(--verde-oliva));
  transform: translateY(-2px);
  box-shadow: 0 6px 12px rgba(0,0,0,0.2);
}
h6{
  position: absolute;
  top:33px;
  right: 350px;
  display: flex;
  gap: 10px;
  z-index: 1000;
}
.page-wrapper {
  
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
  align-items: flex-start;
  padding: 40px;
  max-width: 1200px;
  margin: 0 auto;
}

.container {
  
  background-color: #ffffffee;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 8px 16px rgba(0,0,0,0.1);
  flex: 1 1 300px; /* Flexível, mas mínimo de 300px */
  min-width: 300px;
  max-width: 100%;
  text-align: center;
}



.button-container {
  margin-top: 15px;
}

.button-container a {
  
  display: inline-block;
  text-decoration: none;
  color: white;
  background: linear-gradient(45deg, var(--verde-esmeralda), var(--verde-principal));
  padding: 12px 25px;
  border-radius: 8px;
  font-size: 16px;
  font-weight: bold;
  transition: background-color 0.3s ease, transform 0.2s ease;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.logo {
  
  position:right;
  top: 15px;
  left: 15px;
  z-index:10;
}

.logo img {
  box-shadow: 0 8px 8px rgba(0, 0, 0, 0.3); 
  border-radius: 10px;
  width: 100px; 
  height: auto;
  border-radius:60px;
}
.top-nav {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  background-color: black;
  color: white;
  text-align:center;
  display: flex;
  padding: 20px 30px;
  z-index: 1000;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.top-nav .logo img {
  width: 50px;
  height: auto;
  border-radius: 50%;
  box-shadow: 0 4px 8px rgba(0,0,0,0.3);
}

.top-nav .menu-items {
  display: flex;
  gap: 70px
 
}

.top-nav .menu-items a {
  color: white;
  text-decoration: none;
  font-weight: bold;
  display: flex;
  align-items: center;
  gap: 5px;
  transition: color 0.3s ease;
}

.top-nav .menu-items a:hover {
  color: var(--verde-lima);
}
.footer{
        background-color:black;
        color: white;
        text-align:center;
        padding: 2px;
        position:fixed;
        bottom: 0;
        width: 100%;
    }

</style>

<div class="top-nav">
  <div class="menu-items">
    <a href="<?=base_url('cliente/index')?>"><i data-lucide="home" ></i> Início</a>
    <a href="<?=base_url('cliente/sobre')?>"><i data-lucide="info" ></i> Sobre</a>
    <a href="<?=base_url('cliente/serviços')?>"><i data-lucide="briefcase" ></i> Serviços</a>
    <a href="<?=base_url('cliente/contato')?>"><i data-lucide="mail" ></i> Contato</a>
  </div>
</div>

  <script src="https://unpkg.com/lucide@latest"></script>
  <script>
    lucide.createIcons();
  </script>

<div class="page-wrapper">
  <div class="container">
    <h1 class="titulo1">Bem-vindo à Artesana!</h1>
    <p>Conheça os melhores produtos artesanais do Brasil. Produzidos com carinho, visando a qualidade e valorizando o sustentabilidade do planeta.</p>
    <div class="button-container">
    <?= anchor('Cliente/cadastro', 'Cadastre-se', ['class' => 'btn btn-primary btn-transition', 'data-url' => base_url('Cliente/cadastro')]) ?>
    </div>
  </div>

  <div class="container">
    <h1 class="titulo1">Destaques do Dia</h1>
    <ul style="list-style: none; padding: 0;">
      <li><strong>Sabonetes Naturais</strong> - A partir de R$30</li>
      <li><strong>cremes e hidratantes</strong> - Leve 3, pague 2</li>
      <li><strong>Artesanato em Crochê</strong> - Frete grátis</li>
      <li><strong>Perfumes</strong> - a partir de $119.99</li>
    </ul>
    <div class="button-container">
     <?= anchor('Cliente/questionario', 'Aproveitar', ['class' => 'btn btn-primary btn-transition', 'data-url' => base_url('Cliente/loja')]) ?>
    </div>
  </div>

  <div class="container">
    <h1 class="titulo1">Responda as questoes e ganhe 70% de desconto nas 3 primeiras compras</h1>
    <div class="button-container">
    <?= anchor('Cliente/questionario', 'Ver questionario', ['class' => 'btn btn-primary btn-transition', 'data-url' => base_url('Cliente/questionario')]) ?>
    </div>
  </div>

  <div class="container">
    <h1 class="titulo1">Receba Novidades</h1>
    <p>Cadastre seu e-mail para promoções exclusivas e novos produtos.</p>
    <form>
      <input type="email" placeholder="Seu e-mail" style="padding:10px; width: 80%; border-radius: 8px; border: 1px solid #ccc; margin-bottom:10px;">
      <br>
      <div class="top-button">
      <?= anchor('Cliente/cadastro', 'Cadastrar', ['class' => 'btn btn-primary btn-transition', 'data-url' => base_url('Cliente/index')]) ?>
      </div>
    </form>
  </div>
</div>

<script>
 
  document.querySelectorAll('.btn-transition').forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();

      const url = this.getAttribute('data-url');

      document.body.classList.add('fade-out'); 

      setTimeout(() => {
        window.location.href = url; 
      }, 500); 
    });
  });
</script>
</div>




<br><br><br>
<button type="button" class="btn01" onclick="window.location.href='<?= base_url('cliente/entrega_produto') ?>'">botao de teste entrega</button>


<div class="footer">
&copy; 2025 Artesana. Todos os direitos reservados.
</div>
