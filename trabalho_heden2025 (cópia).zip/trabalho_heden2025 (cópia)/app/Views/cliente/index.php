<style>
    
    .titulo1 {
        text-align: center;
        font-size: 30px;
        color: #333;
        font-family: 'Arial', sans-serif;
        margin-bottom: 20px;
    }

   
    .button-container {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }

    
    .button-container a {
        text-decoration: none;
        color: #fff;
        background-color: #4CAF50; 
        padding: 12px 25px;
        border-radius: 5px;
        font-size: 16px;
        font-weight: bold;
        transition: background-color 0.3s, transform 0.3s;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .button-container a:hover {
        background-color: #45a049; 
        transform: translateY(-3px); 
    }

    .button-container a:active {
        background-color: #388e3c; 
        transform: translateY(0); 
    }

</style>

<div class="container">

    <h1 class="titulo1">Cadastro</h1>
    <div class="button-container">
        <?= anchor('Cliente/novo', 'Cadastrar', ['class' => 'btn btn-primary']) ?>
    </div>

    <div class="container1">
        <h1 class="titulo1">Ir a loja</h1>
        <div class="button-container">
            <?= anchor('Cliente/irloja', 'Visitar loja', ['class' => 'btn btn-primary']) ?>
        </div>
        
    </div>
</div>
