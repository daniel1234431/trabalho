<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Quiz de Sustentabilidade</title>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      background: linear-gradient(to right, #a8e063, #56ab2f);
      margin: 0;
      padding: 0;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .quiz-container {
      background-color: #fff;
      max-width: 600px;
      width: 90%;
      padding: 30px;
      border-radius: 15px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
    }

    h1 {
      text-align: center;
      color: #2e7d32;
      margin-bottom: 20px;
    }

    .question {
      margin-bottom: 20px;
    }

    .question h3 {
      font-size: 18px;
      margin-bottom: 10px;
      color: #333;
    }

    .question label {
      display: block;
      margin-bottom: 8px;
    }

    .submit-btn {
      display: block;
      width: 100%;
      background: #4CAF50;
      color: white;
      border: none;
      padding: 12px;
      font-size: 16px;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s;
    }

    .submit-btn:hover {
      background: #388e3c;
    }

    .button-container {
      text-align: center;
      margin-top: 15px;
    }

    .btn-info {
      text-align: right;
      background-color: #3498db;
      color: white;
      padding: 10px 15px;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      transition: background-color 0.3s;
    }

    .btvolt {
      position: absolute;
      top: 20px;
      left: 20px;
      z-index: 1000;
    }
  </style>
</head>
<body>

<div class="btvolt">
  <?= anchor('Cliente/index', '← Voltar', ['class' => 'btn btn-info']) ?>
</div>

<div class="quiz-container">
  <h1>Quiz: Sustentabilidade</h1>
  <form id="quiz-form" method="post" action="<?= base_url('cliente/salvarRespostas') ?>">

    <div class="question">
      <h3>1. O que significa desenvolvimento sustentável?</h3>
      <label><input type="radio" name="q1" value="errado"> Crescimento econômico ilimitado</label>
      <label><input type="radio" name="q1" value="certo"> Utilizar os recursos naturais de forma consciente</label>
      <label><input type="radio" name="q1" value="errado"> Expandir cidades e indústrias</label>
    </div>

    <div class="question">
      <h3>2. Qual desses materiais é reciclável?</h3>
      <label><input type="radio" name="q2" value="certo"> Plástico</label>
      <label><input type="radio" name="q2" value="errado"> Comida</label>
      <label><input type="radio" name="q2" value="errado"> Tecido sujo</label>
    </div>

    <div class="question">
      <h3>3. Qual é a principal fonte de energia renovável no Brasil?</h3>
      <label><input type="radio" name="q3" value="errado"> Carvão mineral</label>
      <label><input type="radio" name="q3" value="certo"> Hidrelétrica</label>
      <label><input type="radio" name="q3" value="errado"> Petróleo</label>
    </div>

    <div class="question">
      <h3>4. Qual das alternativas reduz a emissão de CO₂?</h3>
      <label><input type="radio" name="q4" value="errado"> Usar mais o carro</label>
      <label><input type="radio" name="q4" value="certo"> Plantar árvores</label>
      <label><input type="radio" name="q4" value="errado"> Desmatar florestas</label>
    </div>

    <div class="question">
      <h3>5. O que é a compostagem?</h3>
      <label><input type="radio" name="q5" value="errado"> Método de queima de lixo</label>
      <label><input type="radio" name="q5" value="certo"> Processo de transformar resíduos orgânicos em adubo</label>
      <label><input type="radio" name="q5" value="errado"> Armazenamento de lixo em lixões</label>
    </div>

    <div class="question">
      <h3>6. Qual ação ajuda a preservar a água potável?</h3>
      <label><input type="radio" name="q6" value="errado"> Lavar calçadas com mangueira</label>
      <label><input type="radio" name="q6" value="certo"> Consertar vazamentos</label>
      <label><input type="radio" name="q6" value="errado"> Deixar torneiras abertas</label>
    </div>

    <div class="question">
      <h3>7. O que significa "pegada de carbono"?</h3>
      <label><input type="radio" name="q7" value="errado"> O número de pegadas em uma trilha</label>
      <label><input type="radio" name="q7" value="certo"> Quantidade de carbono emitida por uma pessoa, empresa ou produto</label>
      <label><input type="radio" name="q7" value="errado"> O tipo de solo afetado pela poluição</label>
    </div>

    <div>
    <?= anchor('Cliente/resultado_quiz', 'Enviar respostas', ['class' => 'btn btn-primary btn-transition', 'data-url' => base_url('Cliente/resultado_quiz')]) ?>
    </div>

  </form>
</div>

<script>
  document.getElementById('quiz-form').addEventListener('submit', function (e) {
    const requiredQuestions = ['q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7'];
    let allAnswered = true;

    for (const question of requiredQuestions) {
      const options = document.getElementsByName(question);
      const isChecked = Array.from(options).some(option => option.checked);
      if (!isChecked) {
        allAnswered = false;
        break;
      }
    }

    if (!allAnswered) {
      e.preventDefault();
      alert("Por favor, responda todas as perguntas antes de enviar.");
    }
  });
</script>

</body>
</html>
