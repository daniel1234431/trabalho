<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar</title>
    <style>
/* Reset básico */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Corpo da página */
body {
  font-family: Arial, sans-serif;
  background: linear-gradient(to right, #a8e063, #56ab2f); /* Gradiente verde moderno */
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

/* Container do formulário */
.form-container {
  background-color: #ffffffee;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 8px 16px rgba(0,0,0,0.1);
  width: 100%;
  max-width: 400px;
}

/* Título */
.titl {
  text-align: center;
  font-size: 28px;
  color: #2e7d32;
  margin-bottom: 25px;
}

/* Campos do formulário */
.form2 {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 6px;
  font-weight: bold;
  color: #333;
}

input[type="nome"],
input[type="email"],
input[type="telefone"],
input[type="password"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 8px;
  box-sizing: border-box;
  transition: border-color 0.3s;
}

input[type="nome"]:focus,
input[type="email"]:focus,
input[type="telefone"]:focus,
input[type="password"]:focus {
  border-color: #4CAF50;
  outline: none;
}

/* Botão principal */
button {
  width: 100%;
  padding: 12px;
  background-color: #4CAF50;
  color: white;
  border: none;
  font-size: 16px;
  cursor: pointer;
  border-radius: 8px;
  transition: background-color 0.3s, transform 0.2s, box-shadow 0.2s;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

button:hover {
  background-color: #388e3c;
  transform: translateY(-2px);
  box-shadow: 0 6px 12px rgba(0,0,0,0.15);
}

/* Links extras */
.voltar, .link-extra {
  text-align: center;
  margin-top: 15px;
}

.voltar a, .link-extra a {
  text-decoration: none;
  color: #007bff;
  font-weight: bold;
  transition: color 0.3s;
}

.voltar a:hover, .link-extra a:hover {
  color: #0056b3;
  text-decoration: underline;
}

/* Responsivo */
@media (max-width: 500px) {
  .form-container {
    padding: 20px;
  }
}
.top-text {
  position: absolute;
  top: 15px;
  left: 15px;
  z-index: 999;
  background-color: rgba(255, 255, 255, 0.85);
  padding: 8px 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.top-text h3 {
  
  margin: 0;
  font-size: 1rem;
  font-weight: normal;
}
.btn-voltar {
  display: inline-block;
  width: 100%;
  padding: 12px;
  background-color: #4CAF50;
  color: white;
  border: none;
  font-size: 16px;
  cursor: pointer;
  border-radius: 8px;
  text-align: center;
  text-decoration: none;
  transition: background-color 0.3s, transform 0.2s, box-shadow 0.2s;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
  margin-top: 10px; /* para espaçar do botão cadastrar */
}

.btn-voltar:hover {
  background-color: #388e3c;
  transform: translateY(-2px);
  box-shadow: 0 6px 12px rgba(0,0,0,0.15);
}

    .footer{
        background-color:black;
        color: white;
        text-align:center;
        padding: 2px;
        position:fixed;
        bottom: 0;
        width: 100%;
    }

</style>
</head>
<body>
  
<div class="top-text">
  <h3><small class="text-body-secondary"> ARTESANA</small></h3>
</div>

<div class="form-container">
    <h1 class="titl">Cadastrar</h1>

    <?= form_open('Cliente/inserir') ?>
        <!--colocar nome-->
        <div class="form2">
            <label for="nome">Nome:</label>
            <input type="nome" name="nome" id="nome" placeholder="Digite seu nome" required>
        </div>
         <!--colocar telefone-->
        <div class="form2">
            <label for="telefone">Telefone:</label>
            <input type="telefone" name="telefone" id="telefone" placeholder="Digite seu número de telefone" required>
        </div>

         <!--colocar email-->
        <div class="form2">
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" placeholder="nome@gmail.com" required>
        </div>
         <!--criar senha-->
        <div class="form2">
            <label for="senha">Senha:</label>
            <input type="password" name="senha" id="senha" autocomplete="off" required>
            <div id="passwordHelpBlock" class="form-text">
                Sua senha deve ter pelo menos 8 caracteres, incluindo letras e números.
            </div>
        </div>
        
         <!--confirmação de senha-->
        <div class="form2">
            <label for="confirma_senha">Confirmar senha:</label>
            <input type="password" name="confirma_senha" id="confirma_senha" autoconfima="off" +required>
        </div>

         <!--botao para se cadastrar-->
        <button type="submit" >Cadastrar</button>
    <?= form_close() ?>

    <!--botao para voltar ao inicio-->
    <a href="<?= base_url('cliente/index') ?>" class="btn-voltar">Voltar</a>

    <!--link para ir fazer login-->
    <div class="link-extra">
        <p>Já tem uma conta? <?= anchor('Cliente/login', 'Faça login') ?></p>
    </div>

    <!--link para ir a loja-->
    <div class="link-extra">
    <p>Deseja visitar a loja? <?= anchor('Cliente/irloja', 'Visitar loja') ?></p>
  </div>
</div>

<script>
  // Função para validar senhas iguais no envio do formulário
  document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const senha = document.getElementById('senha');
    const confirma_senha = document.getElementById('confirma_senha');

    form.addEventListener('submit', function (e) {
      if (senha.value !== confirma_senha.value) {
        e.preventDefault(); // impede o envio do formulário
        alert('A senha e a confirmação nao conferem, por favor, verifique.');
        confirma_senha.focus();
      }
    });
  });
</script>


<div class="footer">
&copy; 2025 Artesana. Todos os direitos reservados.
</div>
</body>
</html>
