<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .form-container {
            max-width: 400px;
            margin: 50px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .form2 {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        button:hover {
            background-color: #218838;
        }

        .voltar, .link-extra {
            text-align: center;
            margin-top: 20px;
        }
        .voltar a, .link-extra a {
            text-decoration: none;
            color: #007bff;
        }
        .voltar a:hover, .link-extra a:hover {
            text-decoration: underline;
        }
        .titl{
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1 class="titl">Cadastrar</h1>

        <?= form_open('Cliente/inserir') ?>
            <div class="form2">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" placeholder="Digite seu nome">
            </div>

            <div class="form2">
                <label for="telefone">Telefone:</label>
                <input type="tel" name="telefone" id="telefone" placeholder="Digite seu número de telefone">
            </div>

            <div class="form2">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" placeholder="nome@gmail.com">
            </div>

            <div class="form2">
                <label for="senha">Senha:</label>
                <input type="password" name="senha" id="senha">
            </div>

            <div class="form2">
                <label for="confirmar_senha">Confirmar senha:</label>
                <input type="password" name="confirmar_senha" id="confirmar_senha">
            </div>

            <button type="submit">Cadastrar</button>
        <?= form_close() ?>

        <div class="voltar">
            <?= anchor('Cliente', 'Voltar') ?>
        </div>

        <div class="link-extra">
            <p>Já tem uma conta? <?= anchor('Cliente/login', 'Faça login') ?></p>
        </div>

        <div class="link-extra">
            <p>Deseja visitar a loja? <?= anchor('Cliente/irloja', 'Visitar loja') ?></p>
    </div>
    
</body>
</html>
