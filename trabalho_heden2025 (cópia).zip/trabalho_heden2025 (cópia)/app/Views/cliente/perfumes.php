<style>
    body {
        font-family: Arial, sans-serif;
        padding: 20px;
    }

    #searchInput {
        width: 300px;
        padding: 8px;
        font-size: 16px;
    }

    ul {
        margin-top: 10px;
    }

    li {
        margin: 5px 0;
    }
    .div4 {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }
    .div4 h2 {
        margin-right: 10px;
    }
    .li1 {
        list-style-type: none;
        margin: 5px 0;
    }
    .li1 a {
        text-decoration: none;
        color: #333;
        padding: 5px 10px;
        border-radius: 4px;
        transition: background-color 0.3s;
    }
    .li1 a:hover {
        background-color: #f0f0f0;
    }
</style>
<div>
    <h2>Perfumes</h2>
    <ul>
        <?php foreach ($perfumes as $perfume): ?>
            <li class="li1">
                <a href="<?= base_url('cliente/loja/' . $perfume['id']) ?>">
                    <?= esc($perfume['nome']) ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>
