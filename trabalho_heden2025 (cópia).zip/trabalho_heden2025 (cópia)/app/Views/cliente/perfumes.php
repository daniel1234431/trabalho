<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Barra de Pesquisa + Galeria</title>
  <style>
    
 
    .st {
  width: 100%;
  max-width: 250px;
  height: auto;
  border-radius: 15px;
  margin-top: 20px;
  object-fit: cover;
}

    body {
  font-family: Arial, sans-serif;
  padding: 20px;
  background-color: #FFF8E1; /* Bege Areia */
  color: #424242; /* Cinza escuro para texto */
}

#searchInput {
  width: 300px;
  padding: 8px;
  font-size: 16px;
  border: 1px solid #81C784;
  border-radius: 8px;
  background-color: #F5F5F5;
}

ul {
  margin-top: 10px;
  border-radius: 30px;
  font-weight: bold;
}

li {
  margin: 5px 0;
}

.div4 {
  position: fixed;
  top: 10px;
  left: 10px;
  background-color: #FFF8E1;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 15px;
  z-index: 1000;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
}

.div4 h2 {
  margin-right: 10px;
}

.li1 a {
  text-decoration: none;
  color: #2E7D32;
  padding: 5px 10px;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.li1 a:hover {
  background-color: #81C784;
}

.topo {
  background-color: #2E7D32;
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 10px;
  width: 100%;
  z-index: 1000;
}

.topo li a {
  color: white;
}

.topo li a:hover {
  background-color: #81C784;
}

.galeria {
  background-color: #FFF8E1;
  display: flex;
  flex-wrap: wrap;
  gap: 30px;
  justify-content: center;
  margin-top: 40px;
  padding: 20px;
}

.imagem-container1 {
  margin-bottom: 20px;
  border: 2px solid #A5D6A7;
  padding: 10px;
  background-color: #F5F5F5;
  border-radius: 15px;
  width: 400px;
  text-align: center;
}

.imagem-container1 p {
  margin-top: 8px;
  font-size: 14px;
}

.cart-button button {
  background-color: #2E7D32;
  color: white;
  padding: 8px 15px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: bold;
}

.cart-button button:hover {
  background-color: #81C784;
  color: #2E7D32;
}

.ps {
  color: #2E7D32;
  font-size: 22px;
  margin: 0;
}
.barra-pesquisa {
  position: fixed;
  top: 10px;
  left: 10px;
  z-index: 1000;
}

.pesquisa {
  width: 100%;
  padding: 10px 20px; /* Ajuste o padding para dar espaço ao ícone */
  font-size: 16px;
  padding-left: 40px; /* Espaço para a lupa dentro da barra */
}
.search-button {
  position: absolute;
  top: 50%;
  left: 10px;
  transform: translateY(-50%);
  background: transparent;
  border: none;
  cursor: pointer;
}
.search-button i {
  font-size: 18px;
  color: #555; /* Cor do ícone */
}

.linkt {
  text-decoration: none;
  color: #2E7D32;
  font-weight: bold;
  padding: 5px 10px;
}

.linkt:hover {
  color: white;
  background-color: #81C784;
  border-radius: 4px;
}

a {
  color: #2E7D32;
}

a:hover {
  color: white;
}

.cart-icon {
  font-size: 20px;
  margin-right: 5px;
}

.cart-button {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 10px;
}

@media (max-width: 500px) {
  .container, .container1 {
    padding: 20px;
  }

  .button-container a {
    width: 100%;
    padding: 12px 0;
    background-color: #2E7D32;
  }
}

.btn.btn-secondary.dropdown-toggle {
  background-color: #A5D6A7;
  color: #2E7D32;
  border: none;
  padding: 10px 20px;
  border-radius: 10px;
  cursor: pointer;
}


    
  </style>
</head>
<body>


<div class="button-container">
        <?= anchor('Cliente/loja', 'Voltar', ['class' => 'btn btn-info']) ?>
    </div>

<div class="div4">
  <h2 class="ps">Pesquisar itens</h2>
  <input class="pesquisa" type="text" id="searchInput" placeholder="Digite para buscar...">
</div>

<div class="drop" data-bs-theme="dark" style="position: fixed; top: 10px; right: 10px; z-index: 1000;">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButtonDark" data-bs-toggle="dropdown" aria-expanded="false">
    <span class="cart-icon"><i class="fas fa-shopping-cart"></i></span>
    <span class="cart-text">Ir para:</span>
  </button>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButtonDark">
    <li><a class="dropdown-item active" href="<?= base_url('cliente/carrinho') ?>">Carrinho</a></li>
    <li><a class="dropdown-item" href="<?= base_url('cliente/historico ') ?>">Historico</a></li>
    <li><a class="dropdown-item" href="<?= base_url('cliente/loja ') ?>">inicio</a></li>
  </ul>
</div>
<br>
<br>

<ul id="itemList">
  <ul class="topo">
    <li><a class="linkt" href="<?= base_url('cliente/perfumes') ?>">Perfumes</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/roupas') ?>">Roupas</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/sabonetes') ?>">Sabonetes</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/esfoliantes') ?>">Esfoliantes</a></li>
    <li><a class="linkt" href="<?= base_url('cliente/cremes_hidratantes') ?>">Cremes/Hidratantes</a></li>
  </ul>
</ul>

<div class="galeria">
  <div class="imagem-container1">
    <img src="/perfume.png" alt="Produto 1" class="st" id='1'>
    <p class = "linkt">nome do produto</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/1') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/perfume2.png" alt="Produto 2" class="st">
    <p class = "linkt">Produto 2</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/2') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/perfume3.png" alt="Produto 3" class="st">
    <p class = "linkt">Produto 3</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/3') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/perfume5.png" alt="Produto 4" class="st">
    <p class = "linkt">Produto 4</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/4') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>
<div class="galeria">
  <div class="imagem-container1">
    <img src="/perfume6.jpg" alt="Produto 1" class="st" id='1'>
    <p class = "linkt">nome do produto</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/5') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/perfume6.jpg" alt="Produto 2" class="st">
    <p class="linkt">Produto 2</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/6') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/perfume7.jpeg" alt="Produto 3" class="st">
    <p class="linkt">Produto 3</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/7') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>

  <div class="imagem-container1">
    <img src="/perfume8.jpeg" alt="Produto 4" class="st">
    <p class = "linkt" >Produto 4</p>
    <div class="cart-button">
      <a href="<?= base_url('cliente/adicionar/8') ?>">
        <button><span class="cart-icon">🛒</span> COMPRAR</button>
      </a>
    </div>
  </div>
</div>


<script>
  const searchInput = document.getElementById("searchInput");
  const produtos = document.querySelectorAll(".imagem-container1");

  searchInput.addEventListener("keyup", function() {
    const filtro = searchInput.value.toLowerCase();

    produtos.forEach(produto => {
      const nome = produto.querySelector("p").textContent.toLowerCase();
      if (nome.includes(filtro)) {
        produto.style.display = "";
      } else {
        produto.style.display = "none";
      }
    });
  });
</script>

</body>
</html>
