<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Formas de Pagamento</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e5f9e0;
            padding: 40px;
            text-align: center;
        }

        h1 {
            color: #2e7d32;
            margin-bottom: 30px;
        }

        .formas-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
            align-items: center;
            max-width: 400px;
            margin: 0 auto;
        }

        .forma {
            background-color: #ffffff;
            padding: 20px;
            border: 2px solid #c8e6c9;
            border-radius: 12px;
            width: 100%;
            transition: transform 0.2s;
            cursor: pointer;
        }

        .forma:hover {
            transform: scale(1.03);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }

        .btn-voltar {
            margin-top: 30px;
            display: inline-block;
            background-color: #388e3c;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .btn-voltar:hover {
            background-color: #2e7d32;
        }
        .formas-container {
    display: flex;
    flex-direction: column;
    gap: 20px;
    align-items: center;
    max-width: 500px;
    margin: 0 auto;
}

.forma-linha {
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 100%;
    background-color: #ffffff;
    border: 2px solid #c8e6c9;
    border-radius: 12px;
    padding: 15px 20px;
}

.forma p {
    margin: 0;
    font-size: 20px;
}

.btn-pagar {
    background-color: #388e3c;
    color: white;
    padding: 8px 16px;
    border-radius: 8px;
    text-decoration: none;
    transition: background-color 0.3s;
}

.btn-pagar:hover {
    background-color: #2e7d32;
}

    </style>
</head>
<body>

    <h1>Escolha a Forma de Pagamento</h1>

    <div class="formas-container">

    <div class="forma-linha">
        <div class="forma">
            <p>💳 Cartão de Crédito</p>
        </div>
        <div class="button-container">
            <?= anchor('Cliente/pagar_cartao', 'Pagar', ['class' => 'btn-pagar']) ?>
        </div>
    </div>

    <div class="forma-linha">
        <div class="forma">
            <p>🏦 Boleto Bancário</p>
        </div>
        <div class="button-container">
            <?= anchor('Cliente/pagar_boleto', 'Pagar', ['class' => 'btn-pagar']) ?>
        </div>
    </div>

    <div class="forma-linha">
        <div class="forma">
            <p>💸 PIX</p>
        </div>
        <div class="button-container">
            <?= anchor('Cliente/pagar_pix', 'Pagar', ['class' => 'btn-pagar']) ?>
        </div>
    </div>

</div>


    <a href="<?= base_url('cliente/loja') ?>" class="btn-voltar">Voltar para a loja</a>

</body>
</html>
