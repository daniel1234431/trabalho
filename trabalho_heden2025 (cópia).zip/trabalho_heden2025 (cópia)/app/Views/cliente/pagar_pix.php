<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Pagamento via PIX</title>
  <style>


</style>
</head>
<style>
  body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f7f9fc;
    margin: 0;
    padding: 20px;
    color: #333;
    text-align: center;
  }

  h2 {
    color: #2c3e50;
    margin-bottom: 10px;
  }

  .btvolt {
    text-align: left;
    margin-bottom: 20px;
  }

  .btn-info {
    background-color: #3498db;
    color: white;
    padding: 10px 15px;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
    transition: background-color 0.3s;
  }

  .btn-info:hover {
    background-color: #2980b9;
  }

  img {
    margin-top: 20px;
    border: 4px solid #2ecc71;
    border-radius: 10px;
    max-width: 90%;
    height: auto;
  }

  .txt1 {
    margin-top: 20px;
    padding: 15px;
    background-color: #ecf0f1;
    border: 1px solid #bdc3c7;
    border-radius: 8px;
    display: inline-block;
  }

  #texto {
    font-size: 1.2em;
    margin-bottom: 10px;
    word-break: break-word;
  }

  .copiar {
    background-color: #2ecc71;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    transition: background-color 0.3s;
  }

  .copiar:hover {
    background-color: #27ae60;
  }

  @media (max-width: 600px) {
    h2 {
      font-size: 1.2em;
    }

    .copiar {
      width: 100%;
    }

    .txt1 {
      width: 90%;
    }
  }
</style>

<body>

  <div class="btvolt">
    <?= anchor('Cliente/pagar', '← Voltar', ['class' => 'btn btn-info']) ?>
  </div>


  <h2>💸 Pagamento via PIX</h2>
  <br>
  <h2>Escaneie o QR-CODE para pagar via PIX</h2>

  
  <img src="/qr-code.png" alt="QR Code PIX" style="width: 200px;"><br><br>
  <p  style="font-family: Arial, sans-serif;">Ou copie o código abaixo:</p>

  <div class="txt1">
  <p id="texto">artesana-92019loja@gmail.com</p>
  <button class="copiar" onclick="copiarTexto()">Copiar chave</button>
 
  
 
  </div>
  <script>
    function copiarTexto() {
      const texto = document.getElementById("texto").innerText;
      navigator.clipboard.writeText(texto).then(() => {
        alert("Chave copiada para a area de transferễncia!");
      }).catch(err => {
        alert("Erro ao copiar a chave, tente novamente: " + err);
      });
    }
  </script>


  
  
</body>
</html>
