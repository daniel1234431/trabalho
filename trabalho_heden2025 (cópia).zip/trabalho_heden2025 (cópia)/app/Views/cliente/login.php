<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .form-container {
            max-width: 400px;
            margin: 50px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            background-image:url('/imagem.jpg');
        }

        .form2 {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="password"] {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        button:hover {
            background-color: #218838;
        }

        .voltar, .link-extra {
            text-align: center;
            margin-top: 20px;
        }
        .voltar a, .link-extra a {
            text-decoration: none;
            color: #007bff;
            border-radius:20px;
        }
        .tit{
            text-align:center;
            
        }
        
        
    </style>
</head>
<body>
    <div class="form-container">
        <h1 class="tit">Faça Login</h1>

        <?= form_open('Cliente/login') ?>
            <div class="form2">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" placeholder="Digite seu nome">
            </div>


            <div class="form2">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" placeholder="nome@gmail.com">
            </div>

            <div class="form2">
                <label for="senha">Senha:</label>
                <input type="password" name="senha" id="senha" placeholder="senha">
            </div>

           

            
        <button class="login3">
            <?= anchor('Cliente/login', 'login') ?>
        </button>
          <br>
          <br>
        <button>
            <?= anchor('Cliente/index', 'Voltar') ?>
        </button>
            <br>
            <br>
        <button>
            <?= anchor('Cliente/loja', 'Loja') ?>
        </button>
        
        

        
    
</body>
</html>
