<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Sobre Nós</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f9f9f9;
      color: #333;
    }

    header {
      background-color: #004aad;
      color: white;
      padding: 20px;
      text-align: center;
    }

    main {
      max-width: 800px;
      margin: 40px auto;
      padding: 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1, h2 {
      color: #004aad;
    }

    p {
      line-height: 1.6;
    }

    footer {
      background-color: #eee;
      text-align: center;
      padding: 10px;
      font-size: 0.9em;
      color: #666;
    }
  </style>
</head>
<body>

  <header>
    <h1>Sobre Nós</h1>
  </header>

  <main>
    <h2>Quem Somos</h2>
    <p>Somos uma equipe dedicada a venda de produtos sustentaveis e focados na preservação do meio-ambiente. Nosso objetivo é ultilizar ao máximo produtos que.</p>

    <h2>Nossa Missão</h2>
    <p>Oferecer produtos e serviços de qualidade, com foco em inovação, usabilidade e satisfação do cliente.</p>

    <h2>História</h2>
    <p>Fundada em 2020, nossa empresa começou com um pequeno time de desenvolvedores apaixonados por tecnologia. Desde então, crescemos e nos tornamos referência em projetos digitais personalizados.</p>
  </main>

  <footer>
   
  </footer>

</body>
</html>
