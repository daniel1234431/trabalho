<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "", "loja");

if ($conn->connect_error) {
  die("Falha na conexão: " . $conn->connect_error);
} else {
  echo "Conexão bem-sucedida!";
}

$conn->close();
?>
