<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Barra de Pesquisa + Galeria</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      background-color:#c7eb7a;
    }

    #searchInput {
      width: 300px;
      padding: 8px;
      font-size: 16px;
    }

    ul {
      margin-top: 10px;
      border-radius:30px;
      font-weight: bold;
      
    }

    li {
      margin: 5px 0;
    }

    .div4 {
      display: flex;
      justify-content: center;
      margin-top: 20px;
      
    }

    .div4 h2 {
      margin-right: 10px;
    }

    .li1 {
      list-style-type: none;
      margin: 5px 0;
    }

    .li1 a {
      text-decoration: none;
      color: #333;
      padding: 5px 10px;
      border-radius: 4px;
      transition: background-color 0.3s;
    }

    .li1 a:hover {
      background-color: #f0f0f0;
    }

    .topo {
      background-color:grey;
      display: flex;
      justify-content: space-around;
      align-items: center;
      padding: 10px;
      width: 100%;
      z-index: 1000;
    }

    .topo li {
      list-style-type: none;
      margin: 0 10px;
    }

    .galeria {
      display: flex;
      flex-wrap: wrap;
      gap: 30px; /* Espaçamento entre as imagens */
      justify-content: center;
      margin-top: 40px;
      padding: 20px;
    }

    .imagem-container1 {
      margin-bottom: 20px;
      border: 1px solid #ccc;
      padding: 10px;
      background-color: #fff;
      border-radius: 15px;
      width: 400px;
      text-align: center;
     
    }

    .imagem-container img {
      width: 100%;
      height: auto;
      border-radius: 4px;
    }

    .imagem-container p {
      margin-top: 8px;
      font-size: 14px;
    }

    .link2 {
      text-decoration: none;
      color: #333;
      padding: 5px 10px;
      border-radius: 4px;
      transition: background-color 0.3s;
    }
    .pesquisa{
      border-radius:30px;
      font-family: Arial, sans-serif;
    }
    .ps{
      font-family: Arial, sans-serif;
      font-size: 50px;
      margin-right: 20px;
      font-weight: bold;
      color:#419f00;
    }
    .volt{
      background-color: #4CAF50;
      
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 16px;
      margin-top: 20px;
      position: absolute;
    }
    .st{
      width: 300px;
      height: 300px;
      border-radius: 15px;
      margin-top: 20px;
    }
    

  </style>
</head>
<body>
<button class="volt">
  <?= anchor('Cliente/login', 'Voltar') ?>
</button>
<div class="div4">
  <h2 class="ps">Pesquisar itens</h2>
  <input class="pesquisa" type="text" id="searchInput" placeholder="Digite para buscar...">
</div>

<ul id="itemList">
  <ul class="topo">
    <li><a href="perfumes.php">Perfumes</a></li>
    <li><a href="Roupas.php">Roupas</a></li>
    <li><a href="Sabonetes.php">Sabonetes</a></li>
    <li><a href="Esfoliantes.php">Esfoliantes</a></li>
    <li><a href="Cremes/hidratantes.php">Cremes/hidratantes</a></li>
  </ul>
</ul>

<div class="galeria">
  <div class="imagem-container1">
    <img src="/imagem.jpg" alt="Nome do produto" class="st">
    <br>
    <br>
    <a class="link2" href="Perfumes/perfumes.php">Nome do produto</a>
    <div class="cart-button">
      <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
    </div>
  </div>
  <div class="imagem-container1">
    <img src="foto2.jpg" alt="Imagem 2">
    <p>Produto 2</p>
    <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
  </div>
  <div class="imagem-container1">
    <img src="foto3.jpg" alt="Imagem 3">
    <p>Produto 3</p>
    <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
  </div>
  <div class="imagem-container1">
    <img src="foto4.jpg" alt="Imagem 4">
    <p>Produto 4</p>
    <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
  </div>
  
</div>
<div class="galeria">
  <div class="imagem-container1">
    <img src="imagem.jpg" alt="Nome do produto" height="200">
    <br>
    <br>
    <a class="link2" href="Perfumes/perfumes.php">Nome do produto</a>
    <div class="cart-button">
      <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
    </div>
  </div>
  <div class="imagem-container1">
    <img src="foto2.jpg" alt="Imagem 2">
    <p>Produto 2</p>
    <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
  </div>
  <div class="imagem-container1">
    <img src="foto3.jpg" alt="Imagem 3">
    <p>Produto 3</p>
    <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
  </div>
  <div class="imagem-container1">
    <img src="foto4.jpg" alt="Imagem 4">
    <p>Produto 4</p>
    <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
  </div>
  
</div>
<div class="galeria">
  <div class="imagem-container1">
    <img src="imagem.jpg" alt="Nome do produto" height="200">
    <br>
    <br>
    <a class="link2" href="Perfumes/perfumes.php">Nome do produto</a>
    <div class="cart-button">
      <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
    </div>
  </div>
  <div class="imagem-container1">
    <img src="foto2.jpg" alt="Imagem 2">
    <p>Produto 2</p>
    <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
  </div>
  <div class="imagem-container1">
    <img src="foto3.jpg" alt="Imagem 3">
    <p>Produto 3</p>
    <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
  </div>
  <div class="imagem-container1">
    <img src="foto4.jpg" alt="Imagem 4">
    <p>Produto 4</p>
    <button onclick="window.location.href='carrinho.php'">
        <span class="cart-icon">🛒</span> COMPRAR
      </button>
  </div>
  
</div>



<script>
  const searchInput = document.getElementById("searchInput");
  const itemList = document.getElementById("itemList").getElementsByTagName("li");

  searchInput.addEventListener("keyup", function() {
    const filter = searchInput.value.toLowerCase();

    for (let i = 0; i < itemList.length; i++) {
      const itemText = itemList[i].textContent.toLowerCase();
      itemList[i].style.display = itemText.includes(filter) ? "" : "none";
    }
  });
</script>

</body>
</html>
