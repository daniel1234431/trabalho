
    <table class='table table-stripped mt-3'>
        <thead class='table table-primary'>
            <tr>
                <th>ID</th>
                <th>NOME</th>
                <th>CPF</th>
                <th>ENDEREÇO</th>
                <th>TELEFONE</th>
                
            </tr>
        </thead>
        <tbody>
            <?php foreach($clientes as $c) : ?>
                <tr>
                    <td><?=$c['id']?></td>
                    <td>
                      <?=anchor(
                        'cliente/editar/'.$c["id"],
                        $c['nome'],
                        ['class'=> 'btn btn-link']
                      )?>  
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody> 
    </table>
</div>